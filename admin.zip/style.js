const scriptURL = 'https://script.google.com/macros/s/AKfycbwGUkVua2RyPqhwPdiZbqsiVMxIS90KewP0Fvscf6adxp6XiUg3UrQi48DA3vSqAe0Etw/exec'; // Replace with your Apps Script web app URL
        const validUsername = 'helloarc'; // Permanent username
        const validPassword = 'arcarc'; // Permanent password

        

        // Initialize the page based on authentication
        document.addEventListener('DOMContentLoaded', () => {
            const isAuthenticated = localStorage.getItem('authenticated') === 'true';
            if (isAuthenticated) {
                document.getElementById('login').style.display = 'none';
                document.getElementById('content').style.display = 'block';
                const isDarkMode = localStorage.getItem('darkMode') === 'true';
                if (isDarkMode) {
                    document.body.classList.add('dark-mode');
                    document.body.classList.remove('light-mode');
                } else {
                    document.body.classList.add('light-mode');
                    document.body.classList.remove('dark-mode');
                }
                loadData();
            } else {
                document.getElementById('login').style.display = 'block';
                document.getElementById('content').style.display = 'none';
            }
        });

        function login() {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (username === validUsername && password === validPassword) {
                localStorage.setItem('authenticated', 'true');
                location.reload(); // Reload to show content
            } else {
                alert('Invalid username or password');
            }
        }

        function logout() {
            localStorage.removeItem('authenticated');
            location.reload(); // Reload to show login page
        }

        function toggleDarkMode() {
            const isDarkMode = document.body.classList.toggle('dark-mode');
            document.body.classList.toggle('light-mode', !isDarkMode);
            localStorage.setItem('darkMode', isDarkMode);
        }

        async function loadData() {
            try {
                const response = await fetch(scriptURL);
                const data = await response.json();

                const dataContainer = document.getElementById('dataContainer');
                const existingCheckboxes = new Set();
                dataContainer.innerHTML = '';

                data.slice(1).forEach((row, index) => {
                    let formattedData = row[1]
                        .replace(/\//g, '<br>')
                        .replace(/email:/gi, '<br>');

                    // Convert phone numbers into clickable links with checkboxes
                    formattedData = formattedData.replace(/(\d{7,15})/g, (phone) => {
                        const checkboxId = `checkbox-${index}-${phone}`;
                        existingCheckboxes.add(checkboxId);
                        const isChecked = localStorage.getItem(checkboxId) === 'true';
                        return `
                            <a href="tel:${phone}" class="phone-link">${phone}</a>
                            ${isChecked ? '<span class="called-text">Called</span>' : `<input type="checkbox" id="${checkboxId}" class="phone-checkbox" ${isChecked ? 'checked disabled' : ''} onclick="handleCheckboxClick('${checkboxId}', this)">`}
                            <br>
                        `;
                    });

                    const card = document.createElement('div');
                    card.className = 'card';
                    card.innerHTML = `
                        <h3>${row[0]}</h3>
                        <p>${formattedData}</p>
                    `;
                    dataContainer.appendChild(card);
                });

                // Remove any localStorage items for checkboxes no longer present
                const storedCheckboxes = Object.keys(localStorage).filter(key => key.startsWith('checkbox-'));
                storedCheckboxes.forEach(key => {
                    if (!existingCheckboxes.has(key)) {
                        localStorage.removeItem(key);
                    }
                });
            } catch (error) {
                console.error('Error loading data:', error);
            }
        }

        function handleCheckboxClick(id, checkbox) {
            if (checkbox.checked) {
                localStorage.setItem(id, 'true');
                checkbox.disabled = true; // Prevent unchecking
                const parent = checkbox.parentElement;
                // Remove any existing 'Called' text before adding it
                const existingText = parent.querySelector('.called-text');
                if (!existingText) {
                    parent.innerHTML += '<span class="called-text">Called</span>'; // Add "Called" text
                }
            } else {
                localStorage.removeItem(id);
                const parent = checkbox.parentElement;
                const existingText = parent.querySelector('.called-text');
                if (existingText) {
                    existingText.remove(); // Remove "Called" text if unchecked
                }
            }
        }

        // Refresh data every second
        setInterval(loadData, 1000);